from flask import Flask, render_template, request, redirect, url_for, flash, session, g, send_file
import pickle
import numpy as np
import sqlite3
import os
import hashlib
from datetime import datetime
from openpyxl import Workbook
import io

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'app.db'

# Load the ML model
model_path = 'model/salary_model.pkl'
if os.path.exists(model_path):
    model = pickle.load(open(model_path, "rb"))
else:
    model = None

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        with open('schema.sql', 'r') as f:
            db.executescript(f.read())

# Helper functions
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Routes
@app.route("/")
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template("index.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = hash_password(request.form["password"])
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password)).fetchone()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('home'))
        flash("Invalid credentials")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = hash_password(request.form["password"])
        email = request.form["email"]
        db = get_db()
        try:
            db.execute('INSERT INTO users (username, password, email) VALUES (?, ?, ?)', (username, password, email))
            db.commit()
            flash("Registration successful")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username or email already exists")
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route("/predict", methods=["POST"])
def predict():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if not model:
        flash("Model not loaded")
        return redirect(url_for('home'))
    experience = float(request.form["experience"])
    education = float(request.form["education"])
    skills = float(request.form["skills"])
    input_data = np.array([[experience, education, skills]])
    prediction = model.predict(input_data)
    salary = round(prediction[0], 2)
    return render_template("index.html", result=salary)

@app.route("/budget")
def budget():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    transactions = db.execute('SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC', (session['user_id'],)).fetchall()
    return render_template("budget.html", transactions=transactions)

@app.route("/add_expense", methods=["POST"])
def add_expense():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    amount = float(request.form["amount"])
    category = request.form["category"]
    type_ = request.form["type"]
    db = get_db()
    db.execute('INSERT INTO transactions (user_id, amount, category, type, date) VALUES (?, ?, ?, ?, ?)',
               (session['user_id'], amount, category, type_, datetime.now().isoformat()))
    db.commit()
    return redirect(url_for('budget'))

from collections import defaultdict

@app.route("/dashboard")
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    period = request.args.get('period', 'all')
    db = get_db()
    transactions = db.execute('SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC', (session['user_id'],)).fetchall()
    income = [t for t in transactions if t['type'] == 'income']
    expense = [t for t in transactions if t['type'] == 'expense']
    total_income = sum(t['amount'] for t in income)
    total_expense = sum(t['amount'] for t in expense)
    balance = total_income - total_expense

    # Aggregate data by period
    def aggregate_by_period(trans_list, period):
        aggregated = defaultdict(float)
        for t in trans_list:
            dt = datetime.fromisoformat(t['date'])
            if period == 'daily':
                key = dt.strftime('%Y-%m-%d')
            elif period == 'weekly':
                # ISO week
                key = f"{dt.isocalendar()[0]}-W{dt.isocalendar()[1]:02d}"
            elif period == 'monthly':
                key = dt.strftime('%Y-%m')
            elif period == 'yearly':
                key = dt.strftime('%Y')
            else:
                key = t['date']  # for 'all', use individual dates
            aggregated[key] += t['amount']
        return dict(aggregated)

    income_agg = aggregate_by_period(income, period) if period != 'all' else {t['date']: t['amount'] for t in income}
    expense_agg = aggregate_by_period(expense, period) if period != 'all' else {t['date']: t['amount'] for t in expense}

    return render_template("dashboard.html", income=income, expense=expense, total_income=total_income, total_expense=total_expense, balance=balance, period=period, income_agg=income_agg, expense_agg=expense_agg)

@app.route("/todo")
def todo():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    todos = db.execute('SELECT * FROM todos WHERE user_id = ? ORDER BY date DESC', (session['user_id'],)).fetchall()
    return render_template("todo.html", todos=todos)

@app.route("/add_todo", methods=["POST"])
def add_todo():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    task = request.form["task"]
    db = get_db()
    db.execute('INSERT INTO todos (user_id, task, done, date) VALUES (?, ?, ?, ?)',
               (session['user_id'], task, False, datetime.now().isoformat()))
    db.commit()
    return redirect(url_for('todo'))

@app.route("/toggle_todo/<int:id>")
def toggle_todo(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    todo = db.execute('SELECT * FROM todos WHERE id = ? AND user_id = ?', (id, session['user_id'])).fetchone()
    if todo:
        db.execute('UPDATE todos SET done = ? WHERE id = ?', (not todo['done'], id))
        db.commit()
    return redirect(url_for('todo'))

@app.route("/jobs")
def jobs():
    db = get_db()
    jobs = db.execute('SELECT * FROM jobs ORDER BY date DESC').fetchall()
    search = request.args.get('search', '')
    location = request.args.get('location', '')
    if search:
        jobs = [j for j in jobs if search.lower() in j['title'].lower() or search.lower() in j['description'].lower()]
    if location:
        jobs = [j for j in jobs if location.lower() in j['location'].lower()]
    return render_template("jobs.html", jobs=jobs, search=search, location=location)

@app.route("/post_job", methods=["GET", "POST"])
def post_job():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == "POST":
        title = request.form["title"]
        company = request.form["company"]
        location = request.form["location"]
        description = request.form["description"]
        salary = request.form["salary"]
        db = get_db()
        db.execute('INSERT INTO jobs (user_id, title, company, location, description, salary, date) VALUES (?, ?, ?, ?, ?, ?, ?)',
                   (session['user_id'], title, company, location, description, salary, datetime.now().isoformat()))
        db.commit()
        return redirect(url_for('jobs'))
    return render_template("post_job.html")

@app.route("/job/<int:id>")
def job_detail(id):
    db = get_db()
    job = db.execute('SELECT * FROM jobs WHERE id = ?', (id,)).fetchone()
    return render_template("job_detail.html", job=job)

@app.route("/apply/<int:id>", methods=["POST"])
def apply_job(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    db.execute('INSERT INTO applications (user_id, job_id, date) VALUES (?, ?, ?)',
               (session['user_id'], id, datetime.now().isoformat()))
    db.commit()
    flash("Application submitted!")
    return redirect(url_for('job_detail', id=id))

@app.route("/export_excel")
def export_excel():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    transactions = db.execute('SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC', (session['user_id'],)).fetchall()
    wb = Workbook()
    ws = wb.active
    ws.title = 'Transactions'
    # Write headers
    headers = ['id', 'user_id', 'amount', 'category', 'type', 'date']
    for col_num, header in enumerate(headers, 1):
        ws.cell(row=1, column=col_num, value=header)
    # Write data
    for row_num, transaction in enumerate(transactions, 2):
        ws.cell(row=row_num, column=1, value=transaction['id'])
        ws.cell(row=row_num, column=2, value=transaction['user_id'])
        ws.cell(row=row_num, column=3, value=transaction['amount'])
        ws.cell(row=row_num, column=4, value=transaction['category'])
        ws.cell(row=row_num, column=5, value=transaction['type'])
        ws.cell(row=row_num, column=6, value=transaction['date'])
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, download_name='transactions.xlsx', as_attachment=True)

if __name__ == "__main__":
    if not os.path.exists(DATABASE):
        init_db()
    app.run(debug=True)