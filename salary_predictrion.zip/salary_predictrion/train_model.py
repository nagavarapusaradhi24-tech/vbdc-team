import csv
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pickle
import os

# Load data from CSV
csv_path = 'salary_data.csv'
data = []
if os.path.exists(csv_path):
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            data.append({
                'experience': float(row['experience']),
                'education': float(row['education']),
                'skills': float(row['skills']),
                'salary': float(row['salary'])
            })
else:
    # Fallback to sample data if CSV not found
    for i in range(10):
        data.append({
            "experience": i+1,
            "education": min(5, (i//2)+1),
            "skills": 40 + i*5,
            "salary": 30000 + i*5000
        })

X = [[d['experience'], d['education'], d['skills']] for d in data]
y = [d['salary'] for d in data]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

# Save the model in model directory
os.makedirs('model', exist_ok=True)
pickle.dump(model, open("model/salary_model.pkl", "wb"))

print("Model saved as model/salary_model.pkl")