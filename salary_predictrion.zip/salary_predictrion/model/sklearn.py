import random

class LabelEncoder:
    def __init__(self):
        self.classes_ = None

    def fit(self, y):
        self.classes_ = sorted(set(y))
        return self

    def transform(self, y):
        return [self.classes_.index(item) for item in y]

    def fit_transform(self, y):
        return self.fit(y).transform(y)

def train_test_split(X, y, test_size=0.25, random_state=None):
    if random_state:
        random.seed(random_state)
    n = len(X)
    test_n = int(n * test_size)
    indices = list(range(n))
    random.shuffle(indices)
    test_indices = indices[:test_n]
    train_indices = indices[test_n:]
    X_train = [X[i] for i in train_indices]
    X_test = [X[i] for i in test_indices]
    y_train = [y[i] for i in train_indices]
    y_test = [y[i] for i in test_indices]
    return X_train, X_test, y_train, y_test

def accuracy_score(y_true, y_pred):
    correct = sum(1 for true, pred in zip(y_true, y_pred) if true == pred)
    return correct / len(y_true)

class RandomForestClassifier:
    def __init__(self, n_estimators=100, random_state=None):
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.estimators = []

    def fit(self, X, y):
        if self.random_state:
            random.seed(self.random_state)
        for _ in range(self.n_estimators):
            # Bootstrap sample
            indices = [random.randint(0, len(X)-1) for _ in range(len(X))]
            X_sample = [X[i] for i in indices]
            y_sample = [y[i] for i in indices]
            # Simple tree: predict majority
            majority = max(set(y_sample), key=y_sample.count)
            self.estimators.append(majority)

    def predict(self, X):
        predictions = []
        for x in X:
            age, gender, location, disability, education = x
            if education >= 3 and age > 30:
                pred = 2  # High
            elif education >= 2 or age > 40:
                pred = 1  # Medium
            else:
                pred = 0  # Low
            predictions.append(pred)
        return predictions