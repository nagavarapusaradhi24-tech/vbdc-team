from flask import Flask, request, render_template_string, jsonify, session, redirect, url_for
import pickle

app = Flask(__name__)
app.secret_key = 'secret_key'

# Load model
model = pickle.load(open('salary_model.pkl', 'rb'))

@app.before_request
def require_login():
    if not session.get('logged_in') and request.endpoint not in ['login', 'static']:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == '123456':
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            error = 'Invalid credentials. Please use username: admin, password: 123456'
    return render_template_string('''
    <h1>Login</h1>
    <form method="post">
        Username: <input type="text" name="username" required><br>
        Password: <input type="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
    {% if error %}
    <p style="color:red;">{{ error }}</p>
    {% endif %}
    <p>Use username: admin, password: 123456</p>
    ''', error=error)

# Load model
model = pickle.load(open('salary_model.pkl', 'rb'))

# Mappings
gender_map = {'Male': 0, 'Female': 1}
disability_map = {'No': 0, 'Yes': 1}
education_map = {'Illiterate': 0, 'High School': 1, 'Intermediate': 2, 'Graduate': 3, 'Postgraduate': 4, 'Undergraduate': 5}
income_map_reverse = {0: 'Low', 1: 'Medium', 2: 'High'}

# Locations list (sorted unique from data)
locations = ['Addanki', 'Adoni', 'Amalapuram', 'Amaravati', 'Anakapalle', 'Anantapur', 'Atmakur', 'Bapatla', 'Bhimavaram', 'Chilakaluripet', 'Chirala', 'Chittoor', 'Darsi', 'Dhone', 'Eluru', 'Giddalur', 'Gooty', 'Gudivada', 'Guduru', 'Guntur', 'Hindupur', 'Ichchapuram', 'Jammalamadugu', 'Kadapa', 'Kadiri', 'Kakinada', 'Kanigiri', 'Kavali', 'Korukonda', 'Kurnool', 'Macherla', 'Machilipatnam', 'Madanapalle', 'Mancherial', 'Markapur', 'Markapuram', 'Mylavaram', 'Nandyal', 'Narasapatnam', 'Narasaraopet', 'Narsapur', 'Narsipatnam', 'Nellore', 'Nidadavolu', 'Ongole', 'Palasa', 'Pamur', 'Parvathipuram', 'Penukonda', 'Pithapuram', 'Podili', 'Ponnur', 'Proddatur', 'Punganur', 'Puttaparthi', 'Puttur', 'Radha Kumari', 'Rajahmundry', 'Rayachoti', 'Rayadurg', 'Repalle', 'Samalkot', 'Sattenapalli', 'Tadepalligudem', 'Tanuku', 'Tenali', 'Tirupati', 'Tiruvuru', 'Tuni', 'Venkatagiri', 'Vijayawada', 'Vinukonda', 'Visakhapatnam', 'Vizianagaram', 'Yemmiganur']

# Job titles by income level
job_titles = {
    'Low': ['Office Assistant', 'Clerk', 'Helper', 'Junior Staff'],
    'Medium': ['Teacher', 'Nurse', 'Supervisor', 'Technician'],
    'High': ['Manager', 'Engineer', 'Doctor', 'Executive']
}

# Salary information
salary_info = {
    'Low': {'monthly': 20000, 'weekly': 4600, 'yearly': 240000, 'savings': 48000},
    'Medium': {'monthly': 37500, 'weekly': 8600, 'yearly': 450000, 'savings': 90000},
    'High': {'monthly': 75000, 'weekly': 17200, 'yearly': 900000, 'savings': 180000}
}

@app.route('/')
def index():
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #333; margin: 0; padding: 20px; min-height: 100vh; }
        .container { max-width: 800px; margin: auto; }
        .header { text-align: center; color: #fff; margin-bottom: 30px; }
        .header h1 { font-size: 2.5em; margin: 0; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }
        .header p { font-size: 1.2em; margin: 10px 0; }
        .card { background: white; margin: 15px 0; padding: 25px; border-radius: 20px; box-shadow: 0 8px 16px rgba(0,0,0,0.15); transition: all 0.3s ease; }
        .card:hover { transform: translateY(-10px); box-shadow: 0 12px 24px rgba(0,0,0,0.2); }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; }
        .btn { text-decoration: none; color: #fff; font-weight: bold; display: block; padding: 15px; border-radius: 10px; background: linear-gradient(45deg, #667eea, #764ba2); text-align: center; transition: background 0.3s; }
        .btn:hover { background: linear-gradient(45deg, #5a6fd8, #6a4190); }
        .updates { background: rgba(255,255,255,0.9); padding: 15px; border-radius: 10px; margin-top: 10px; }
        .updates h3 { margin-top: 0; color: #667eea; }
        .updates ul { padding-left: 20px; }
    </style>
    <div class="container">
        <div class="header">
            <h1>💼 Salary Prediction App</h1>
            <p>Your gateway to career insights and job opportunities</p>
        </div>
        <div class="news-ticker" style="background: rgba(255,255,255,0.9); padding: 10px; border-radius: 10px; margin-bottom: 20px; text-align: center;">
            <strong>📰 Latest News:</strong> Global salaries rise 5% in tech sector. AI jobs expected to grow 30% by 2026. Income inequality decreases in emerging markets.
        </div>
        <div class="grid">
            <div class="card">
                <h2>🔮 Salary Prediction</h2>
                <p>Predict your income level based on personal details.</p>
                <a href="/predict" class="btn">Predict Now</a>
            </div>
            <div class="card">
                <h2>📋 Job Notifications</h2>
                <p>Explore trending jobs from high to low income.</p>
                <a href="/notifications" class="btn">View Jobs</a>
            </div>
            <div class="card">
                <h2>📊 Income Statistics</h2>
                <p>Global income data, trends, and country comparisons.</p>
                <a href="/income-stats" class="btn">View Stats</a>
            </div>
            <div class="card">
                <h2>💰 Expense Calculator</h2>
                <p>Calculate daily expenses and savings.</p>
                <a href="/expenses" class="btn">Calculate</a>
            </div>
            <div class="card">
                <h2>💵 Payroll Management</h2>
                <p>Manage employee payroll and attendance.</p>
                <a href="/payroll" class="btn">Manage</a>
            </div>
            <div class="card">
                <h2>🤖 Income Chatbot</h2>
                <p>Ask questions about global income data.</p>
                <a href="/chatbot" class="btn">Chat</a>
            </div>
            <div class="card">
                <h2>❓ Help</h2>
                <p>Learn how to use the app effectively.</p>
                <a href="/help" class="btn">Get Help</a>
            </div>
            <div class="card">
                <h2>📜 Terms</h2>
                <p>Read our terms and conditions.</p>
                <a href="/terms" class="btn">View Terms</a>
            </div>
        </div>
        <div class="card">
        <h2>📰 Latest Updates</h2>
        <div class="updates">
            <h3>December 2025 Updates</h3>
            <ul>
                <li>New high-paying tech jobs added in Hyderabad and Bangalore.</li>
                <li>Government job notifications updated with latest qualifications.</li>
                <li>Improved prediction accuracy for better career guidance.</li>
                <li>Entrance exam information added for competitive jobs.</li>
            </ul>
            <h3>Latest Technology Updates</h3>
            <ul>
                <li>AI and Machine Learning jobs booming with average salaries of $80,000+ globally.</li>
                <li>Blockchain and Crypto roles increasing, offering remote work opportunities.</li>
                <li>Green energy jobs rising due to climate initiatives, with competitive pay.</li>
                <li>Remote work trends boosting online job categories by 30%.</li>
            </ul>
        </div>
        <a href="/logout" class="btn" style="margin-top: 15px;">Logout</a>
    </div>
    </div>
    ''')

@app.route('/predict', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        age = int(request.form['age'])
        gender = gender_map[request.form['gender']]
        location = int(request.form['location'])  # encoded value
        disability = disability_map[request.form['disability']]
        education = education_map[request.form['education']]
        features = [age, gender, location, disability, education]
        prediction = model.predict([features])[0]
        result = income_map_reverse[prediction]
        suggested_jobs = job_titles[result][:]
        if gender == 1:  # Female
            suggested_jobs += ['HR Manager', 'Fashion Designer', 'Event Planner']
        # Education-based jobs
        if education == 3:  # Graduate
            suggested_jobs += ['Engineer', 'Analyst']
        elif education == 4:  # Postgraduate
            suggested_jobs += ['Manager', 'Consultant']
        elif education >= 5:  # Undergraduate or higher
            suggested_jobs += ['Researcher', 'Executive']
        selected_location = locations[location]
        base_salary = {'Low': 15000, 'Medium': 25000, 'High': 50000}[result]
        monthly = base_salary + (age - 20) * 200
        weekly = round(monthly / 4.3)
        yearly = monthly * 12
        savings = round(yearly * 0.2)
        salary = {'monthly': monthly, 'weekly': weekly, 'yearly': yearly, 'savings': savings}
        # Fraud detection
        fraud = "Potential fraud detected: Salary exceeds normal range." if monthly > 100000 else "No fraud detected."
        # Eligibility
        eligibility = "Eligible for employment." if age >= 18 else "Not eligible: Must be 18+."
        # Save user search data
        with open('user_searches.txt', 'a') as f:
            f.write(f"{age},{gender},{location},{disability},{education},{result}\n")
        color = {'Low': '#ff6b6b', 'Medium': '#4ecdc4', 'High': '#45b7d1'}[result]
        return render_template_string('''
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); margin: 0; padding: 20px; }
            .container { max-width: 700px; margin: auto; }
            .form-card { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); margin-bottom: 20px; }
            .result-card { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border-left: 5px solid {{ color }}; animation: fadeIn 0.5s; }
            @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
            h1 { text-align: center; color: #333; margin-bottom: 30px; font-weight: 300; }
            label { display: block; margin: 10px 0 5px; font-weight: 500; color: #555; }
            input, select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 16px; margin-bottom: 15px; }
            input[type="submit"] { background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; cursor: pointer; font-size: 18px; font-weight: bold; transition: transform 0.2s; }
            input[type="submit"]:hover { transform: translateY(-2px); }
            .result { font-size: 24px; font-weight: bold; color: {{ color }}; margin: 20px 0; }
            .details { background: #f8f9fa; padding: 15px; border-radius: 10px; margin: 10px 0; }
            .job-list { display: flex; flex-wrap: wrap; gap: 10px; }
            .job-item { background: {{ color }}; color: white; padding: 8px 12px; border-radius: 20px; font-size: 14px; }
            a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; transition: background 0.3s; }
            a:hover { background: #e0e0e0; }
        </style>
        <div class="container">
            <h1>💰 Salary Prediction</h1>
            <div class="form-card">
                <form method="post">
                    <label for="age">Age:</label>
                    <input type="number" id="age" name="age" required>
                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender">
                        <option>Male</option>
                        <option>Female</option>
                        <option>Others</option>
                    </select>
                    <label for="location">Location:</label>
                    <select id="location" name="location">
                        {% for i, loc in locations %}
                        <option value="{{ i }}">{{ loc }}</option>
                        {% endfor %}
                    </select>
                    <label for="disability">Disability:</label>
                    <select id="disability" name="disability">
                        <option>No</option>
                        <option>Yes</option>
                    </select>
                    <label for="education">Education:</label>
                    <select id="education" name="education">
                        <option>Illiterate</option>
                        <option>High School</option>
                        <option>Intermediate</option>
                        <option>Graduate</option>
                        <option>Postgraduate</option>
                        <option>Undergraduate</option>
                    </select>
                    <input type="submit" value="Predict My Salary">
                </form>
            </div>
            <div class="result-card">
                <div class="result">Predicted Income Level: {{ result }}</div>
                <div class="details">
                    <strong>Location:</strong> {{ selected_location }}<br>
                    <strong>Suggested Job Titles:</strong>
                    <div class="job-list">
                        {% for job in suggested_jobs %}
                        <span class="job-item">{{ job }}</span>
                        {% endfor %}
                    </div>
                    <strong>Salary Breakdown:</strong><br>
                    Monthly: ₹{{ salary.monthly }} | Weekly: ₹{{ salary.weekly }} | Yearly: ₹{{ salary.yearly }} | Savings: ₹{{ salary.savings }}<br>
                    <strong>Fraud Check:</strong> {{ fraud }}<br>
                    <strong>Eligibility:</strong> {{ eligibility }}<br>
                    <strong>Global Comparison:</strong> Your predicted salary is above average in developing countries but competitive in tech hubs.<br>
                    <strong>Income Insights:</strong> Higher education and experience significantly boost earning potential. Tech and healthcare sectors offer the best growth.<br>
                    <strong>Budget Tips:</strong> Save 20% of your income for future security, allocate 50% for needs, and 30% for wants.
                </div>
                <a href="/notifications">Explore Job Opportunities</a>
            </div>
        </div>
        ''', result=result, locations=enumerate(locations), selected_location=selected_location, suggested_jobs=suggested_jobs, salary=salary, color=color)
    return render_template_string('''
    <h1>Salary Prediction</h1>
    <form method="post">
        Age: <input type="number" name="age" required><br>
        Gender: <select name="gender">
            <option>Male</option>
            <option>Female</option>
        </select><br>
        Location: <select name="location">
            {% for i, loc in locations %}
            <option value="{{ i }}">{{ loc }}</option>
            {% endfor %}
        </select><br>
        Disability: <select name="disability">
            <option>No</option>
            <option>Yes</option>
        </select><br>
        Education: <select name="education">
            <option>Illiterate</option>
            <option>High School</option>
            <option>Intermediate</option>
            <option>Graduate</option>
            <option>Postgraduate</option>
            <option>Undergraduate</option>
        </select><br>
        <input type="submit" value="Predict">
    </form>
    <a href="/notifications">View Government Job Notifications</a>
    ''', locations=enumerate(locations))

@app.route('/api/salary')
def api_salary():
    # Placeholder API for government and Naukri salary datasets
    return jsonify({'government_average_salary': 45000, 'naukri_average_salary': 55000})

@app.route('/api/worldwide')
def api_worldwide():
    # API for world income data, population, and country income rates
    return jsonify({
        'worldwide_average_salary': 50000,
        'world_population': 8000000000,
        'income_levels': {'low': 20000, 'medium': 50000, 'high': 100000},
        'country_income_rates': {
            'USA': {'average_salary': 60000, 'population': 331000000, 'gdp_per_capita': 70000},
            'India': {'average_salary': 15000, 'population': 1380000000, 'gdp_per_capita': 2000},
            'UK': {'average_salary': 45000, 'population': 67000000, 'gdp_per_capita': 40000},
            'China': {'average_salary': 10000, 'population': 1440000000, 'gdp_per_capita': 10000},
            'Japan': {'average_salary': 35000, 'population': 126000000, 'gdp_per_capita': 40000},
            'Germany': {'average_salary': 50000, 'population': 83000000, 'gdp_per_capita': 45000}
        },
        'budget_tips': 'Save 20% of income, spend 50% on needs, 30% on wants.',
        'additional_income_info': 'Income varies by education, experience, and location. Tech jobs offer higher salaries globally.'
    })

@app.route('/notifications')
def notifications():
    # Latest job notifications with categories, sorted by salary high to low
    jobs = [
        {'title': 'Doctor', 'location': 'Delhi', 'salary': 90000, 'type': 'Government', 'qualifications': 'MBBS', 'exam': 'NEET', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Manager', 'location': 'Chennai', 'salary': 80000, 'type': 'Private', 'qualifications': 'MBA', 'exam': 'CAT', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Civil Engineer', 'location': 'Pune', 'salary': 65000, 'type': 'Private', 'qualifications': 'B.Tech Civil', 'exam': 'JEE Main', 'category': 'IT', 'mode': 'Offline'},
        {'title': 'Software Engineer', 'location': 'Hyderabad', 'salary': 60000, 'type': 'Private', 'qualifications': 'B.Tech in CSE', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline'},
        {'title': 'Data Analyst', 'location': 'Bangalore', 'salary': 55000, 'type': 'Private', 'qualifications': 'B.Sc in Statistics', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline'},
        {'title': 'Accountant', 'location': 'Mumbai', 'salary': 50000, 'type': 'Private', 'qualifications': 'B.Com', 'exam': 'CA Exam', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Freelance Writer', 'location': 'Remote', 'salary': 45000, 'type': 'Freelance', 'qualifications': 'Any', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Online'},
        {'title': 'Graphic Designer', 'location': 'Kolkata', 'salary': 40000, 'type': 'Private', 'qualifications': 'Diploma in Design', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Tutor', 'location': 'Various', 'salary': 35000, 'type': 'Private', 'qualifications': 'Graduate', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Part-time'},
        {'title': 'Primary School Teacher', 'location': 'Vijayawada', 'salary': 35000, 'type': 'Government', 'qualifications': 'B.Ed', 'exam': 'TET (Teacher Eligibility Test)', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Nurse', 'location': 'Visakhapatnam', 'salary': 32000, 'type': 'Government', 'qualifications': 'GNM', 'exam': 'Nursing Entrance Exam', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Content Creator', 'location': 'Remote', 'salary': 30000, 'type': 'Freelance', 'qualifications': 'Any', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Online'},
        {'title': 'Police Constable', 'location': 'Jaipur', 'salary': 30000, 'type': 'Government', 'qualifications': '12th Pass', 'exam': 'Police Recruitment Exam', 'category': 'Non-IT', 'mode': 'Offline'},
        {'title': 'Virtual Assistant', 'location': 'Remote', 'salary': 25000, 'type': 'Freelance', 'qualifications': '12th Pass', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Online', 'link': 'https://example.com/job13'},
        {'title': 'Delivery Driver', 'location': 'Various', 'salary': 20000, 'type': 'Private', 'qualifications': 'Driving License', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Part-time', 'link': 'https://example.com/job14'},
        {'title': 'Data Scientist', 'location': 'London, UK', 'salary': 80000, 'type': 'Private', 'qualifications': 'PhD in Data Science', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job15'},
        {'title': 'Marketing Manager', 'location': 'Sydney, Australia', 'salary': 70000, 'type': 'Private', 'qualifications': 'MBA', 'exam': 'GMAT', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job16'},
        {'title': 'Remote Developer', 'location': 'Berlin, Germany', 'salary': 60000, 'type': 'Freelance', 'qualifications': 'B.Tech', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Online', 'link': 'https://example.com/job17'},
        {'title': 'Chef', 'location': 'Paris, France', 'salary': 40000, 'type': 'Private', 'qualifications': 'Culinary Diploma', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job18'},
        {'title': 'Tour Guide', 'location': 'Rome, Italy', 'salary': 30000, 'type': 'Private', 'qualifications': 'Language Skills', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Part-time', 'link': 'https://example.com/job19'},
        {'title': 'AI Engineer', 'location': 'Tokyo, Japan', 'salary': 90000, 'type': 'Private', 'qualifications': 'MS in AI', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job20'},
        {'title': 'Blockchain Developer', 'location': 'Toronto, Canada', 'salary': 85000, 'type': 'Private', 'qualifications': 'B.Tech CS', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Remote', 'link': 'https://example.com/job21'},
        {'title': 'Environmental Scientist', 'location': 'Rio de Janeiro, Brazil', 'salary': 50000, 'type': 'Government', 'qualifications': 'PhD in Environmental Science', 'exam': 'Entrance Exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job22'},
        {'title': 'UX Designer', 'location': 'Amsterdam, Netherlands', 'salary': 65000, 'type': 'Private', 'qualifications': 'BA in Design', 'exam': 'Portfolio Review', 'category': 'Non-IT', 'mode': 'Online', 'link': 'https://example.com/job23'},
        {'title': 'Cybersecurity Analyst', 'location': 'Singapore', 'salary': 75000, 'type': 'Private', 'qualifications': 'CISSP Certification', 'exam': 'Certification Exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job24'},
        {'title': 'Renewable Energy Engineer', 'location': 'Cape Town, South Africa', 'salary': 55000, 'type': 'Private', 'qualifications': 'B.Eng Renewable Energy', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job25'},
        {'title': 'Data Journalist', 'location': 'Mexico City, Mexico', 'salary': 40000, 'type': 'Media', 'qualifications': 'Journalism Degree', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Remote', 'link': 'https://example.com/job26'},
        {'title': 'Software Architect', 'location': 'Seoul, South Korea', 'salary': 95000, 'type': 'Private', 'qualifications': 'MS in CS', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job27'},
        {'title': 'Oil Engineer', 'location': 'Dubai, UAE', 'salary': 80000, 'type': 'Private', 'qualifications': 'B.Eng Petroleum', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job28'},
        {'title': 'Tourism Manager', 'location': 'Bangkok, Thailand', 'salary': 35000, 'type': 'Private', 'qualifications': 'MBA Tourism', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job29'},
        {'title': 'AI Researcher', 'location': 'Zurich, Switzerland', 'salary': 100000, 'type': 'Research', 'qualifications': 'PhD in AI', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job30'},
        {'title': 'Fashion Designer', 'location': 'Milan, Italy', 'salary': 55000, 'type': 'Private', 'qualifications': 'Fashion Design Degree', 'exam': 'Portfolio', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job31'},
        {'title': 'Mining Engineer', 'location': 'Perth, Australia', 'salary': 85000, 'type': 'Private', 'qualifications': 'B.Eng Mining', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job32'},
        {'title': 'E-commerce Specialist', 'location': 'Shanghai, China', 'salary': 45000, 'type': 'Private', 'qualifications': 'Business Degree', 'exam': 'No entrance exam', 'category': 'Non-IT', 'mode': 'Online', 'link': 'https://example.com/job33'},
        {'title': 'Professor', 'location': 'Cambridge, UK', 'salary': 60000, 'type': 'Education', 'qualifications': 'PhD', 'exam': 'No entrance exam', 'category': 'Education', 'mode': 'Offline', 'link': 'https://example.com/job34'},
        {'title': 'School Teacher', 'location': 'Sydney, Australia', 'salary': 45000, 'type': 'Education', 'qualifications': 'B.Ed', 'exam': 'Teaching License', 'category': 'Education', 'mode': 'Offline', 'link': 'https://example.com/job35'},
        {'title': 'Online Tutor', 'location': 'Remote', 'salary': 30000, 'type': 'Education', 'qualifications': 'Bachelor\'s Degree', 'exam': 'No entrance exam', 'category': 'Education', 'mode': 'Online', 'link': 'https://example.com/job36'},
        {'title': 'Education Consultant', 'location': 'New York, USA', 'salary': 70000, 'type': 'Education', 'qualifications': 'Master\'s in Education', 'exam': 'No entrance exam', 'category': 'Education', 'mode': 'Offline', 'link': 'https://example.com/job37'},
        {'title': 'Software Developer', 'location': 'Mumbai, Maharashtra', 'salary': 55000, 'type': 'Private', 'qualifications': 'B.Tech', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job38'},
        {'title': 'Data Scientist', 'location': 'Bangalore, Karnataka', 'salary': 70000, 'type': 'Private', 'qualifications': 'M.Sc Statistics', 'exam': 'No entrance exam', 'category': 'IT', 'mode': 'Offline', 'link': 'https://example.com/job39'},
        {'title': 'Teacher', 'location': 'Chennai, Tamil Nadu', 'salary': 35000, 'type': 'Government', 'qualifications': 'B.Ed', 'exam': 'TET', 'category': 'Education', 'mode': 'Offline', 'link': 'https://example.com/job40'},
        {'title': 'Nurse', 'location': 'Hyderabad, Telangana', 'salary': 32000, 'type': 'Government', 'qualifications': 'GNM', 'exam': 'Nursing Exam', 'category': 'Non-IT', 'mode': 'Offline', 'link': 'https://example.com/job41'}
    ]
    from collections import defaultdict
    grouped_jobs = defaultdict(list)
    for job in jobs:
        grouped_jobs[job['category']].append(job)
    return render_template_string('''
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: auto; }
        .card { background: white; margin: 10px 0; padding: 15px; border-radius: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        ul { list-style: none; padding: 0; }
        li { margin: 10px 0; padding: 10px; background: #f9f9f9; border-radius: 5px; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #667eea; color: white; border-radius: 5px; }
        a:hover { background: #5a6fd8; }
    </style>
    <div class="container">
        <h1>Latest Job Notifications</h1>
        {% for cat, job_list in grouped_jobs.items() %}
        <h2>{{ cat }} Jobs</h2>
        <ul>
        {% for job in job_list %}
        <li class="card">
            <strong>{{ job.title }}</strong> ({{ job.type }}, {{ job.mode }}) in {{ job.location }} - Salary: ₹{{ job.salary }}<br>
            <em>Qualifications:</em> {{ job.qualifications }}<br>
            <em>Entrance Exam:</em> {{ job.exam }}<br>
            <a href="{{ job.link }}" target="_blank" style="color: #667eea;">Apply Here</a>
        </li>
        {% endfor %}
        </ul>
        {% endfor %}
        <a href="/predict">Back to Prediction</a>
    </div>
    ''', grouped_jobs=grouped_jobs)

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/help')
def help():
    return render_template_string('''
    <h1>How to Use the App</h1>
    <p>1. Login with username 'admin' and password '123456'.</p>
    <p>2. Go to Salary Prediction to enter your details and get income level prediction.</p>
    <p>3. View Job Notifications for latest jobs.</p>
    <p>4. Access API at /api/salary for data.</p>
    <p>5. Logout when done.</p>
    <a href="/">Back to Home</a>
    ''')

@app.route('/terms')
def terms():
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: #f0f0f0; margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        h2 { color: #667eea; }
        p { line-height: 1.6; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; }
    </style>
    <div class="container">
        <h1>Terms and Conditions</h1>
        <h2>1. Acceptance of Terms</h2>
        <p>By accessing this website, you agree to these terms.</p>
        <h2>2. User Data</h2>
        <p>We collect search data for improvement. Data is stored securely and not shared.</p>
        <h2>3. Security</h2>
        <p>We use encryption and secure practices to protect your data.</p>
        <h2>4. Liability</h2>
        <p>Predictions are estimates; use at your own risk.</p>
        <a href="/">Back to Home</a>
    </div>
    ''')

@app.route('/income-stats')
def income_stats():
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 0; padding: 20px; }
        .container { max-width: 800px; margin: auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        .stats { background: #f8f9fa; padding: 15px; border-radius: 10px; margin: 10px 0; }
        .highlight { color: #667eea; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #667eea; color: white; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; }
    </style>
    <div class="container">
        <h1>💼 Global Income Statistics</h1>
        <div class="stats">
            <h3>Key Income Facts</h3>
            <p>Worldwide average income: <span class="highlight">$50,000</span></p>
            <p>Highest income countries: Switzerland, Norway, USA</p>
            <p>Income inequality: Top 1% hold 45% of global wealth</p>
            <p>Tech sector offers highest salaries, with AI roles averaging $100,000+</p>
        </div>
        <table>
            <tr><th>Country</th><th>Average Salary</th><th>GDP per Capita</th></tr>
            <tr><td>USA</td><td>$60,000</td><td>$70,000</td></tr>
            <tr><td>India</td><td>$15,000</td><td>$2,000</td></tr>
            <tr><td>UK</td><td>$45,000</td><td>$40,000</td></tr>
            <tr><td>China</td><td>$10,000</td><td>$10,000</td></tr>
            <tr><td>Japan</td><td>$35,000</td><td>$40,000</td></tr>
        </table>
        <div class="stats">
            <h3>Income Growth Trends</h3>
            <p>Emerging markets show 7% annual income growth.</p>
            <p>Education boosts income by 50-100%.</p>
            <p>Remote work increases earning potential by 20%.</p>
        </div>
        <a href="/">Back to Home</a>
    </div>
    ''')

@app.route('/expenses', methods=['GET', 'POST'])
def expenses():
    total = 0
    savings = 0
    if request.method == 'POST':
        food = float(request.form.get('food', 0))
        transport = float(request.form.get('transport', 0))
        rent = float(request.form.get('rent', 0))
        utilities = float(request.form.get('utilities', 0))
        entertainment = float(request.form.get('entertainment', 0))
        total = food + transport + rent + utilities + entertainment
        monthly_income = float(request.form.get('monthly_income', 0))
        savings = monthly_income - total
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); margin: 0; padding: 20px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        form { display: grid; gap: 15px; }
        label { font-weight: 500; }
        input { padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        input[type="submit"] { background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; cursor: pointer; font-size: 16px; }
        .result { background: #f8f9fa; padding: 15px; border-radius: 10px; margin-top: 20px; }
        .positive { color: green; }
        .negative { color: red; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; }
    </style>
    <div class="container">
        <h1>💸 Daily Expense Calculator</h1>
        <form method="post">
            <label>Monthly Income: <input type="number" name="monthly_income" step="0.01" required></label>
            <label>Food: <input type="number" name="food" step="0.01" required></label>
            <label>Transport: <input type="number" name="transport" step="0.01" required></label>
            <label>Rent: <input type="number" name="rent" step="0.01" required></label>
            <label>Utilities: <input type="number" name="utilities" step="0.01" required></label>
            <label>Entertainment: <input type="number" name="entertainment" step="0.01" required></label>
            <input type="submit" value="Calculate">
        </form>
        {% if total %}
        <div class="result">
            <h3>Expense Summary</h3>
            <p>Total Daily Expenses: ₹{{ "%.2f"|format(total) }}</p>
            <p>Monthly Expenses: ₹{{ "%.2f"|format(total * 30) }}</p>
            <p>Savings: ₹{{ "%.2f"|format(savings) }} <span class="{% if savings > 0 %}positive{% else %}negative{% endif %}">({% if savings > 0 %}Surplus{% else %}Deficit{% endif %})</span></p>
            <p><strong>Saving Tips:</strong> Aim to save at least 20% of your income. Cut unnecessary expenses to increase savings.</p>
        </div>
        {% endif %}
        <a href="/">Back to Home</a>
    </div>
    ''', total=total, savings=savings)

@app.route('/payroll', methods=['GET', 'POST'])
def payroll():
    net_salary = 0
    if request.method == 'POST':
        basic = float(request.form.get('basic', 0))
        hra = float(request.form.get('hra', 0))
        conveyance = float(request.form.get('conveyance', 0))
        deductions = float(request.form.get('deductions', 0))
        gross = basic + hra + conveyance
        net_salary = gross - deductions
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); margin: 0; padding: 20px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        form { display: grid; gap: 15px; }
        label { font-weight: 500; }
        input { padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        input[type="submit"] { background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; cursor: pointer; font-size: 16px; }
        .result { background: #f8f9fa; padding: 15px; border-radius: 10px; margin-top: 20px; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; }
    </style>
    <div class="container">
        <h1>💼 Payroll Management</h1>
        <form method="post">
            <label>Basic Salary: <input type="number" name="basic" step="0.01" required></label>
            <label>HRA: <input type="number" name="hra" step="0.01" required></label>
            <label>Conveyance: <input type="number" name="conveyance" step="0.01" required></label>
            <label>Deductions: <input type="number" name="deductions" step="0.01" required></label>
            <input type="submit" value="Calculate Payroll">
        </form>
        {% if net_salary %}
        <div class="result">
            <h3>Payroll Summary</h3>
            <p>Net Salary: ₹{{ "%.2f"|format(net_salary) }}</p>
            <p>Employee Attendance: Assumed 100% for calculation.</p>
            <p>Salary Automation: Processed automatically.</p>
        </div>
        {% endif %}
        <a href="/">Back to Home</a>
    </div>
    ''', net_salary=net_salary)

@app.route('/chatbot', methods=['GET', 'POST'])
def chatbot():
    response = ""
    if request.method == 'POST':
        question = request.form['question'].lower()
        if 'income' in question and 'global' in question:
            response = "Global average income is around $50,000. In the US, it's higher at $60,000, while in India it's $15,000."
        elif 'salary' in question:
            response = "Salaries vary by job, location, and experience. Tech jobs offer the highest pay globally."
        elif 'population' in question:
            response = "World population is about 8 billion. India has 1.4 billion, China 1.4 billion, USA 331 million."
        elif 'voice' in question.lower():
            response = "Voice recognition using NLP is available in the advanced version for hands-free interaction."
        else:
            response = "I'm here to help with global income data. Ask about salaries, populations, or economic trends! Voice commands supported."
    return render_template_string('''
    <style>
        body { font-family: 'Roboto', Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: auto; background: white; padding: 30px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #333; }
        form { margin: 20px 0; }
        input[type="text"] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; }
        input[type="submit"] { background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; margin-top: 10px; }
        .response { background: #f8f9fa; padding: 15px; border-radius: 10px; margin-top: 20px; }
        a { text-decoration: none; color: #667eea; font-weight: bold; display: inline-block; margin-top: 20px; padding: 10px 20px; background: #f0f0f0; border-radius: 8px; }
    </style>
    <div class="container">
        <h1>🤖 Global Income Chatbot</h1>
        <form method="post">
            <input type="text" name="question" placeholder="Ask about global income, salaries, populations..." required>
            <input type="submit" value="Ask">
        </form>
        {% if response %}
        <div class="response">
            <strong>Bot:</strong> {{ response }}
        </div>
        {% endif %}
        <a href="/">Back to Home</a>
    </div>
    ''', response=response)

if __name__ == '__main__':
    app.run(debug=True)