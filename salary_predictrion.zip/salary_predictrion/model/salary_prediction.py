import csv
from sklearn import train_test_split, RandomForestClassifier, accuracy_score, LabelEncoder
import pickle

# Read data
data = []
with open('AP_Citizen.csv', 'r') as f:
    reader = csv.reader(f)
    header = next(reader)
    for row in reader:
        if row == header:  # skip duplicate headers
            continue
        data.append(row)

# Indices
citizen_id_idx = 0
name_idx = 1
age_idx = 2
gender_idx = 3
aadhaar_idx = 4
location_idx = 5
income_level_idx = 6
disability_idx = 7
education_idx = 8

# Encode
gender_map = {'Male': 0, 'Female': 1}
disability_map = {'No': 0, 'Yes': 1}
education_map = {'Illiterate': 0, 'High School': 1, 'Intermediate': 2, 'Graduate': 3, 'Postgraduate': 4, 'Undergraduate': 5}
income_map = {'Low': 0, 'Medium': 1, 'High': 2}

le_location = LabelEncoder()
locations = [row[location_idx] for row in data]
le_location.fit(locations)

# Prepare X and y
X = []
y = []
for row in data:
    age = int(row[age_idx])
    gender = gender_map[row[gender_idx]]
    location = le_location.transform([row[location_idx]])[0]
    disability = disability_map[row[disability_idx]]
    education = education_map[row[education_idx]]
    income = income_map[row[income_level_idx]]
    X.append([age, gender, location, disability, education])
    y.append(income)

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'Model Accuracy: {accuracy:.2f}')

# Save model
pickle.dump(model, open('salary_model.pkl', 'wb'))
print('Model saved as salary_model.pkl')