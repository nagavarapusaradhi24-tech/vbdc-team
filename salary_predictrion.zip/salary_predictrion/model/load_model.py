import pickle

# Load the model
model = pickle.load(open('salary_model.pkl', 'rb'))

# Example prediction
# Features: Age, Gender (0=Male,1=Female), Location (encoded), Disability (0=No,1=Yes), Education (0=Illiterate to 5=Undergraduate)

sample_data = [30, 0, 10, 0, 3]  # Example: 30 year old male, location 10, no disability, graduate

prediction = model.predict([sample_data])

income_levels = ['Low', 'Medium', 'High']

print(f'Predicted Income Level for sample data: {income_levels[prediction[0]]}')